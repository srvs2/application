<?php 
if(!empty($_FILES)){
$total = count($_FILES['uploadFile']['name']);

// Loop through each file
for( $i=0 ; $i < $total ; $i++ ) {

  //Get the temp file path
  $tmpFilePath = $_FILES['uploadFile']['tmp_name'][$i];

  //Make sure we have a file path
  if ($tmpFilePath != ""){
    //Setup our new file path
    $newFilePath = "./uploads/" . $_FILES['uploadFile']['name'][$i];



    if(move_uploaded_file($tmpFilePath, $newFilePath)) {

      }
    }
 }
 echo "file uploaded";
}





















?>